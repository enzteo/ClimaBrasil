import os
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

BASE_DIR = Path(__file__).parent

# URL pública vem de variável de ambiente (nunca fixa no código).
# Canonical e sitemap apontando para localhost em produção é erro de SEO.
SITE_URL = (os.getenv("SITE_URL") or "http://localhost:3000").rstrip("/")

app = FastAPI(title="Site")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/health")
def health():
    # Depois, quando houver banco, este endpoint só responde 200
    # se a conexão com o banco estiver funcionando.
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(
        request,
        "home.html",
        {"site_url": SITE_URL, "canonical": f"{SITE_URL}/"},
    )
